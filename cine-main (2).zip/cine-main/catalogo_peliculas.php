<html>
<head>
    <meta charset="UTF-8">
    <title>Crear Película</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<div class="image-and-text">
        <img src="img/logo.png" alt="Imagen">
       
    </div>
    <body>
    <nav>
<ul class="dropdown">
        	<li class="drop"><a href="index.php">Inicio</a></li>
        	<li class="drop"><a href="catalogo_peliculas.php">Ver peliculas</a></li>
        	<li class="drop"><a href="series.php">Ver series</a>
        	<ul class="sub_menu"></ul>
        	</li>
        	<li><a href="login.php">Login</a>
        	</li>
        </ul>
</nav> 
    <body>
        <br>    
    <div class="slider-container">
        <div class="slider">
            <img src="img/venger.jpg" alt="Imagen 1">
            <img src="img/days28.jpg" alt="Imagen 2">
            <img src="img/elemental.jpg" alt="Imagen 3">
            <img src="img/mk.jpg" alt="Imagen 4">
        </div>
    </div>  
</main>
<h1>Peliculas</h1>
    <div class="blog-entry">
        <div class="blog-post">
        <h2>Avengers</h2>
            <img class="blog-image" src="img/venger.jpg" alt="Imagen 1">
            <p class="blog-description">La película fue anunciada en octubre de 2014 como Avengers: Infinity War - Parte 2, pero Marvel retiró posteriormente este título. Los hermanos Russo se unieron como directores en abril de 2015, y Markus y McFeely firmaron para escribir el guion un mes después. La película sirve como conclusión de la historia del UCM hasta ese momento, poniendo fin a los arcos argumentales de varios personajes principales. La trama retoma varios momentos de las películas anteriores, trayendo .</p>
        </div>
        <div class="blog-post">
        <h2>Elemental</h2>
            <img class="blog-image" src="img/elemental.jpg" alt="Imagen 2">
            <p class="blog-description">Elemental (titulada Elementos en Hispanoamérica) es una película de fantasía romántica animada por computadora estadounidense producida por Walt Disney Pictures y Pixar Animation Studios y distribuida por Walt Disney Studios Motion Pictures. Dirigida por Peter Sohn y producida por Denise Ream y Ricardo Arnaiz a partir de un guion de Brenda Hsueh, cuenta con Leah Lewis y Mamoudou Athie en los papeles principales de voz. La película describe el vínculo entre Ember (Lewis), un elemento fuego, y Wade (Athie), que no pueden tocarse; pero descubre cuánto tienen en común.</p>
            <a href="Entradas/entrada_1.php">Ver AHORA</a>
        </div>
        <div class="blog-post">
        <h2>Exterminio 2</h2>
            <img class="blog-image" src="img/days28.jpg" alt="Imagen 3">
            <p class="blog-description">La película comienza cuando Don (Robert Carlyle) y su esposa Alice (Catherine McCormack), que están escondidos en una cabaña en una zona rural de Inglaterra junto con otros supervivientes, son atacados por una manada de personas infectadas con el "virus de la rabia" de la primera película. Al momento del ataque, Don y Alice corren junto a un niño que antes había llegado para refugiarse, pero Don los deja atrás y corre hasta un río cercano donde se salva gracias a una lancha que estaba cerca.

                                Poco después, subtítulos muestran el desastre causado por la infección mortal del virus mutante: la cuarentena del Reino Unido, la muerte de los infectados por inanición, y la posterior llegada del ejército de Estados Unidos junto con fuerzas de la OTAN a Londres, para comenzar la repoblación 28 semanas después de los acontecimientos narrados.</p>
                                <a href="crear.php">Ver AHORA</a>
                            </div>
    </div>
<script src="scrip/files.js"></script>
</body>
<footer>
        &copy; 2023 El señor de las peliculas  
    </footer>

</html>

