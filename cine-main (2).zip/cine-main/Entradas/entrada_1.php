<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>title1</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
    <link rel="stylesheet" href="../css/styles.css">
    </header>

    <main>
    <ul class="menu">
    <body>
    <main>
<li><a href="../index.php">Inicio</a></li>
        <li><a href="../crear.php">Crear</a></li>
      
        
        <li><a href="../ver.php">Ver</a></li>

       
        
    </ul>

        <article class="entrada">
        <h1>Elemental</h1>
            
            <img src="../img/elemental.jpg" alt="Imagen de la entrada">
            <p>
            Elemental (titulada Elementos en Hispanoamérica) es una película de fantasía romántica animada por computadora estadounidense producida por Walt Disney Pictures y Pixar Animation Studios y distribuida por Walt Disney Studios Motion Pictures. Dirigida por Peter Sohn y producida por Denise Ream y Ricardo Arnaiz a partir de un guion de Brenda Hsueh, cuenta con Leah Lewis y Mamoudou Athie en los papeles principales de voz. La película describe el vínculo entre Ember (Lewis), un elemento fuego, y Wade (Athie), que no pueden tocarse; pero descubre cuánto tienen en común.
            </p>
        </article>
        <h2>Ver Pelicula Completa</h2> 
        <iframe width="560" height="315" src="https://www.youtube.com/watch?v=7KIWqmLsJRM" frameborder="0" allowfullscreen></iframe>
        <!-- Puedes agregar más entradas aquí -->
    </main>

    <footer>
        &copy; 2023 El serñor de las peliculas  
    </footer>
</body>
</html>
