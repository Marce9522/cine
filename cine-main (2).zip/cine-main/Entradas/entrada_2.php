<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exterminio2</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
       
    </header>

    <main>
    <ul class="menu">
    <body>
    <main>
<li><a href="../index.php">Inicio</a></li>
        <li><a href="../crear.php">Crear</a></li>
      
        
        <li><a href="../ver.php">Ver</a></li>

       
        
    </ul>

        <article class="entrada">
        <h1>Elemental</h1>
            
            <img src="../img/days28.jpg" alt="Imagen de la entrada">
            <p>
            En el centro de investigación de primates de Cambridge una incursión de activistas a favor de los derechos de los animales accede a un laboratorio de investigación científica, con la intención de liberar a un grupo de chimpancés que están siendo utilizados en experimentos secretos. Movidos por su fanatismo, los activistas deciden liberar a los animales desoyendo las advertencias que en el último momento les lanza uno de los asustados científicos encargados del proyecto, acerca de que los primates están infectados con un virus mutante artificial que provoca una terrible enfermedad nerviosa, manifestándose en forma de incontrolable agresividad y violencia.

Uno de los activistas somete al científico, que insiste en explicarles las consecuencias del virus, pero liberan a uno de los chimpancés, el cual ataca a la mujer activista. El otro activista se lo quita, pero ya es tarde: la activista se infecta con un tipo de enfermedad de una variante del virus de la rabia y comienza a atacar a todo el que tiene enfrente. Dada la facilidad de infección del virus (basta el contacto con sangre o saliva de un infectado) y corto periodo de incubación (de 10 a 20 segundos), la epidemia pronto se extiende, transformando a casi toda la población de Inglaterra en seres violentos y primitivos.
            </p>
        </article>
        <h2>Ver Pelicula Completa</h2> 
        <iframe width="560" height="315" src="https://www.dailymotion.com/video/x7ysed3" frameborder="0" allowfullscreen></iframe>
        <!-- Puedes agregar más entradas aquí -->
    </main>

    <footer>
        &copy; 2023 El serñor de las peliculas  
    </footer>
</body>
</html>
